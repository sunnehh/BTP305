#include <iomanip>
#include "Dictionary.h"
#include "Queue.h"

namespace sdds {
	using namespace std;


	ostream& Dictionary::display(ostream& os) const{
		os << setw(20) << right << m_term << ": ";
		os << setw(80) << left << m_definition;
		return os;
	}


	ostream& operator<<(ostream& os, const Dictionary& dictionary) {
		dictionary.display(os);
		return os;
	}

	Dictionary::Dictionary() {
		m_term = "";
		m_definition = "";
	}

	bool operator==(const Dictionary& lhs, const Dictionary& rhs) {
		bool issame = false;
		if ((lhs.getTerm() == rhs.getTerm()) && (lhs.getDefinition() == rhs.getDefinition()) )
		{
			issame = true;
		}
		return issame;
	}

	Dictionary::Dictionary(const Dictionary& other) : m_term{ other.m_term }, m_definition{ other.m_definition } {
	}

	Dictionary& Dictionary::operator=(const Dictionary& other) {
		m_term = other.m_term;
		m_definition = other.m_definition;
		return *this;
	}

	Dictionary& Dictionary::operator=(const int& other) {
		if (other == NULL)
		{
			this->m_term = "";
			this->m_definition = "";
		}
		return *this;
	}
}