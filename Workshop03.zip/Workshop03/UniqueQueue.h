#ifndef SDDS_UNIQUE_QUEUE_H
#define SDDS_UNIQUE_QUEUE_H

#include <cmath>
#include "Queue.h"

namespace sdds {
	template<typename T>
	class UniqueQueue : public Queue<T, 100>
	{
	public:
		bool push(T item) override {
			bool success = false;
			bool dupe = false;
			if (Queue<T, 100>::m_num_elements < 100)
			{
				for (int i = 0; (i < 5) && !dupe; ++i)
				{
					if (Queue<T, 100>::m_queue[i] == item)
					{
						dupe = true;
					}
				}
				if (!dupe)
				{
					Queue<T, 100>::push(item);
				}
			}
			return success;
		};
	};

	bool UniqueQueue<double>::push(double item) {
		bool success = false;
		bool dupe = false;
		if (Queue<double, 100>::m_num_elements < 100)
		{
			for (int i = 0; (i < 100) && !dupe; ++i)
			{
				if (Queue<double, 100>::m_queue[i] != NULL)
				{
					double compare = abs((Queue<double, 100>::m_queue[i] - item));
					if (compare < 0.005)
					{
						dupe = true;
					}
				}
			}
			if (!dupe)
			{
				Queue<double, 100>::push(item);
			}
		}
		return success;
	};


}
#endif